let player;
let seeds = [];
let obstacles = [];
let score = 0;

function setup() {
  createCanvas(800, 600);
  player = new Player();
  for (let i = 0; i < 5; i++) {
    seeds.push(new Seed());
    obstacles.push(new Obstacle());
  }
}

function draw() {
  background(200, 255, 200); // Cor de fundo representando o campo
  player.update();
  player.show();

  for (let i = seeds.length - 1; i >= 0; i--) {
    seeds[i].show();
    if (player.collect(seeds[i])) {
      seeds.splice(i, 1);
      score++;
    }
  }

  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].show();
    if (player.collide(obstacles[i])) {
      obstacles.splice(i, 1);
      score--;
    }
  }

  fill(0);
  textSize(24);
  text("Pontuação: " + score, 10, 30);
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.size = 50;
    this.speed = 5;
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.speed;
    if (keyIsDown(UP_ARROW)) this.y -= this.speed;
    if (keyIsDown(DOWN_ARROW)) this.y += this.speed;

    this.x = constrain(this.x, 0, width - this.size);
    this.y = constrain(this.y, 0, height - this.size);
  }

  show() {
    fill(255, 204, 0); // Cor do jogador (representando um agricultor)
    noStroke();
    ellipse(this.x, this.y, this.size);
  }

  collect(seed) {
    let d = dist(this.x, this.y, seed.x, seed.y);
    return d < this.size / 2 + seed.size / 2;
  }

  collide(obstacle) {
    let d = dist(this.x, this.y, obstacle.x, obstacle.y);
    return d < this.size / 2 + obstacle.size / 2;
  }
}

class Seed {
  constructor() {
    this.x = random(width);
    this.y = random(height - 100);
    this.size = 20;
  }

  show() {
    fill(0, 255, 0); // Cor das sementes
    noStroke();
    ellipse(this.x, this.y, this.size);
  }
}

class Obstacle {
  constructor() {
    this.x = random(width);
    this.y = random(height - 100);
    this.size = 30;
  }

  show() {
    fill(139, 69, 19); // Cor dos obstáculos (representando pedras)
    noStroke();
    ellipse(this.x, this.y, this.size);
  }
}
